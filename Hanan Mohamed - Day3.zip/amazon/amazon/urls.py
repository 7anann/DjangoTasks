"""amazon URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from home.views import welcome
from contactUS.views import contact
from aboutUs.views import about
#from affairs.views import registeruser,login,home, addstud, update,delete,selectall, search
from affairs.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('registeruser', addusertoadmin),
    path('login', loginuserandadmin),
    path('mylogout', mylogout, name="mylogout"),
    path('list', TrackList.as_view()),
    path('insert', insertstud),
    path('insert2', insertstudusingModelForm)
   # path('wel/<name>', welcome),
   # path('con', contact),
   # path('about', about),
   # path('registeruser', registeruser),
   # path('login', login),
   # path('home', home),
   # path('add', addstud),
   # path('update', update),
   # path('del', delete),
   # path('sel', selectall),
   # path('search', search)
]
